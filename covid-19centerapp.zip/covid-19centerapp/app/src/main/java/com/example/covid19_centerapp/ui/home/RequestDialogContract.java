package com.example.covid19_centerapp.ui.home;

import androidx.annotation.NonNull;

import com.example.covid19_centerapp.base.BasePresenter;
import com.example.covid19_centerapp.data.model.ReceiverDonorRequestType;
import com.example.covid19_centerapp.ui.home.model.RequestDetails;

public interface RequestDialogContract {
  interface View {
    void getLastLocation();

    void dismissDialog(@NonNull String userId, boolean isReceiver, ReceiverDonorRequestType receiverDonorRequestType);
  }

  interface Presenter extends BasePresenter {

    void onSubmitButtonClick(RequestDetails requestDetails);

    void onLocationClick();
  }
}
