package com.example.covid19_centerapp.ui.userdetail;

import com.example.covid19_centerapp.base.BasePresenter;
import com.example.covid19_centerapp.base.BaseView;
import com.example.covid19_centerapp.ui.userdetail.model.UserDetail;


public interface UserDetailContract {
    interface Presenter extends BasePresenter {
        void onCreateNowClick(UserDetail userDetail);

        void onDobButtonClick();

        void onLocationClick();
    }

    interface View extends BaseView {
        void showDatePickerDialog();

        void getLastLocation();

        void launchHomeScreen();

    }
}
