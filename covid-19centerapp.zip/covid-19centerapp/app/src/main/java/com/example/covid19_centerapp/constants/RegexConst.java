package com.example.blood_donationapp.constants;


final public class RegexConst {
    private RegexConst() {
    }

    public final static String PASSWORD_PATTERN =
            "^(?=.*[0-9])(?=.*[A-Z])(?=.*[@#$%^&+=!])(?=\\S+$).{4,}$";
}
