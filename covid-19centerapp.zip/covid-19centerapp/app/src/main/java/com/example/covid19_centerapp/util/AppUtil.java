package com.example.covid19_centerapp.util;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

public final class AppUtil {
    private AppUtil() {
    }

    public static void replaceFragmentInActivity(FragmentManager fragmentManager, Fragment fragment,
            int containerId) {
        fragmentManager.beginTransaction().replace(containerId, fragment).commit();
    }
}
