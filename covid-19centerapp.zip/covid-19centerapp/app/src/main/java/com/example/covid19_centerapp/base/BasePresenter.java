package com.example.covid19_centerapp.base;


public interface BasePresenter {
  void onCreate();

  void onStart();

  void onStop();

  void onDestroy();
}
