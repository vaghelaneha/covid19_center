package com.example.covid19_centerapp.data.source;

import com.example.covid19_centerapp.data.model.ReceiverDonorRequestType;
import com.example.covid19_centerapp.data.model.User;

public interface DonationDataSource {
  void saveNewUser(String userId, User user);

  void saveReceiverDetails(String userId, ReceiveruserRequestType receiveruserRequestType);

  void saveuserDetails(String userId, ReceiveruserRequestType receiveruserRequestType);
}
