package com.example.covid19_centerapp.base;

import androidx.annotation.StringRes;

public interface BaseView {


    void generalResponse(@StringRes int responseId);
}
