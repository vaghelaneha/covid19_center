package com.example.covid19_centerapp.data.source.local;

import com.example.covid19_centerapp.data.model.ReceiverDonorRequestType;
import com.example.covid19_centerapp.data.model.User;
import com.example.covid19_centerapp.data.source.DonationDataSource;


public class DonationLocalDataSource implements DonationDataSource {

    private static DonationLocalDataSource INSTANCE;

    private DonationLocalDataSource() {
    }

    public static DonationDataSource getInstance() {
        if (INSTANCE == null) {
            synchronized (DonationLocalDataSource.class) {
                if (INSTANCE == null) {
                    INSTANCE = new DonationLocalDataSource();
                }
            }
        }
        return INSTANCE;
    }

    @Override
    public void saveNewUser(String userId, User user) {
        throw new UnsupportedOperationException("Not supported");
    }

    @Override
    public void saveReceiverDetails(String userId, ReceiveruseRequestType receiveruserRequestType) {

    }

    @Override
    public void saveuserDetails(String userId, ReceiveruserRequestType receiveruserRequestType) {

    }
}
